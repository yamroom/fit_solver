
# -*- coding: utf-8 -*-
"""
plots.py
--------
依 i 繪圖：多條 g 曲線，標示觀測與缺失預測。
"""
from __future__ import annotations
from typing import Dict, List, Tuple
import os

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def plot_by_i(outdir: str,
              df: pd.DataFrame,
              fspec,
              theta_by_g: Dict[str, np.ndarray],
              grids_plot: Dict[float, np.ndarray],
              s_dir: Dict[Tuple[str, float], int]) -> None:
    odir = os.path.join(outdir, "plots_by_i")
    os.makedirs(odir, exist_ok=True)

    for i_val, xgrid in sorted(grids_plot.items(), key=lambda kv: kv[0]):
        fig = plt.figure()
        ax = plt.gca()
        sub_i = df[df["i"] == i_val]
        g_values = sorted(sub_i["g"].astype(str).unique().tolist())
        # 曲線
        for g in g_values:
            i_arr = np.full_like(xgrid, i_val, dtype=float)
            fhat = fspec.eval_f(i_arr, xgrid, theta_by_g[g])
            ax.plot(xgrid, fhat, label=f"g={g}")
        # 觀測點與缺失點標示
        for g in g_values:
            sub_gi = sub_i[sub_i["g"].astype(str) == g]
            obs = sub_gi.dropna(subset=["y"])
            mis = sub_gi[sub_gi["y"].isna()]
            if len(obs) > 0:
                ax.scatter(obs["x"].values, obs["y"].values, marker="o", s=18, alpha=0.7)
            if len(mis) > 0 and "y_hat" in mis.columns:
                ax.scatter(mis["x"].values, mis["y_hat"].values, marker="x", s=28, alpha=0.9)
        # 標題包含單調方向
        dirs = []
        for g in g_values:
            s = s_dir.get((g, float(i_val)), +1)
            dirs.append(f"{g}:{'↑' if s>0 else '↓'}")
        ax.set_title(f"i={i_val} | 單調方向 " + ", ".join(dirs))
        ax.set_xlabel("x")
        ax.set_ylabel("f(g,i,x)")
        ax.legend(loc="best", fontsize=8)
        ax.grid(True, alpha=0.3)
        fpath = os.path.join(odir, f"i={i_val}.png")
        fig.tight_layout()
        fig.savefig(fpath, dpi=140)
        plt.close(fig)
