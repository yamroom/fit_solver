
# -*- coding: utf-8 -*-
"""
grids.py
--------
格點產生與 x 工作區間界定。
"""
from __future__ import annotations
from typing import Dict, List, Tuple, Optional
import numpy as np
import pandas as pd

def compute_x_range(df: pd.DataFrame, x_grid_args: Optional[List[float]]) -> Tuple[float, float, int]:
    if x_grid_args and len(x_grid_args) == 3:
        min_x, max_x, N = float(x_grid_args[0]), float(x_grid_args[1]), int(x_grid_args[2])
    else:
        min_x = float(np.nanmin(df["x"].values))
        max_x = float(np.nanmax(df["x"].values))
        N = 201
    if not (max_x > min_x):
        raise ValueError("x 範圍不合法（max_x 必須大於 min_x）。")
    return min_x, max_x, N

def linspace(min_x: float, max_x: float, N: int) -> np.ndarray:
    return np.linspace(min_x, max_x, int(N))

def build_grids(df: pd.DataFrame, min_x: float, max_x: float,
                N_mono: int = 101, N_cross: int = 201, N_plot: int = 201) -> Dict:
    """
    回傳字典：
    {
        "mono": { (g,i): x_array },
        "cross": { i: x_array },
        "plot": { i: x_array },
    }
    """
    mono = {}
    cross = {}
    plot = {}
    # 觀測 x 也一併納入對應網格（單調與交叉）
    for (g, i), sub in df.groupby(["g", "i"], dropna=False):
        xs = np.unique(np.concatenate([linspace(min_x, max_x, N_mono), sub["x"].dropna().values]))
        mono[(str(g), float(i))] = np.sort(xs)
    for i, sub in df.groupby(["i"], dropna=False):
        xs = np.unique(np.concatenate([linspace(min_x, max_x, N_cross), sub["x"].dropna().values]))
        cross[float(i)] = np.sort(xs)
        plot[float(i)] = linspace(min_x, max_x, N_plot)
    return {"mono": mono, "cross": cross, "plot": plot}
