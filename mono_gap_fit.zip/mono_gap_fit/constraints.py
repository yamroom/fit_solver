
# -*- coding: utf-8 -*-
"""
constraints.py
--------------
提供從 optimizer.make_constraints 拆出的別名，以便主程式組裝使用。
（實際約束定義放在 optimizer.py 內的 make_constraints）
"""
from __future__ import annotations
from typing import Dict, List, Tuple

# 這個模組僅保留接口占位，讓結構更清晰。
# 具體 NonlinearConstraint 的建構使用 optimizer.make_constraints。

def monotonic_constraints(*args, **kwargs):
    from optimizer import make_constraints
    cons = make_constraints(*args, **kwargs)
    # 第一個 constraint 便是單調，見 make_constraints 實作
    return [cons[0]]

def gap_constraints(*args, **kwargs):
    from optimizer import make_constraints
    cons = make_constraints(*args, **kwargs)
    # 第二個 constraint 為 gap
    return [cons[1]]

def denom_constraints(*args, **kwargs):
    from optimizer import make_constraints
    cons = make_constraints(*args, **kwargs)
    # 可能不存在（若非有理函數）
    return cons[2:] if len(cons) > 2 else []
