
# -*- coding: utf-8 -*-
"""
合成資料端到端測試（簡化）：
f(x,i;θ_g) = (exp(i) + a1_g * x + b1_g) / (1 + c2_g * x)
"""
from __future__ import annotations
import os
import tempfile
import numpy as np
import pandas as pd

from fit_and_predict import run_pipeline

def make_synth(Kg: int = 3, Ii: int = 3, N_per: int = 50, seed: int = 0):
    rng = np.random.default_rng(seed)
    g_list = [f"g{k+1}" for k in range(Kg)]
    i_vals = np.linspace(0.5, 1.5, Ii)
    rows = []
    true_params = {}
    for gi, g in enumerate(g_list):
        a1 = 0.5 + 0.2*gi
        b1 = 0.1 * (gi+1)
        c2 = 0.05 + 0.02*gi
        true_params[g] = (a1, b1, c2)
        for i in i_vals:
            xs = rng.uniform(-2, 2, size=N_per)
            for x in xs:
                y = (np.exp(i) + a1*x + b1) / (1.0 + c2*x)
                y += rng.normal(scale=0.05)
                rows.append((g, i, x, y))
    df = pd.DataFrame(rows, columns=["g","i","x","y"])
    # 隨機挖空 20%
    mask = rng.random(len(df)) < 0.2
    df.loc[mask, "y"] = np.nan
    return df, true_params

def test_e2e_synth():
    df, _ = make_synth()
    with tempfile.TemporaryDirectory() as td:
        data_csv = os.path.join(td, "data.csv")
        func_txt = os.path.join(td, "function.txt")
        outdir = os.path.join(td, "out")
        df.to_csv(data_csv, index=False)
        with open(func_txt, "w", encoding="utf-8") as f:
            f.write("(exp(i) + a1*x + b1) / (1 + c2*x)")
        run_pipeline([
            "--data", data_csv,
            "--func", func_txt,
            "--outdir", outdir,
            "--lambda", "0.5",
            "--gamma", "10.0",
            "--epsilon", "1e-6",
            "--rho-th", "0.2",
            "--gap-delta", "1e-3",
            "--maxiter", "200"
        ])
        # 基本輸出檢查
        assert os.path.exists(os.path.join(outdir, "params_by_g.csv"))
        assert os.path.exists(os.path.join(outdir, "data_with_predictions.csv"))
        assert os.path.exists(os.path.join(outdir, "full_grid_by_i.csv"))
        assert os.path.isdir(os.path.join(outdir, "plots_by_i"))
