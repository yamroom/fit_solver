
# -*- coding: utf-8 -*-
from __future__ import annotations
from func_parser import extract_param_names, build_callables

def test_extract_order():
    expr = "(exp(i) + a1*x^2 + b1*x) / (a2*x^3 + b2*x^2 + c2)"
    params = extract_param_names(expr)
    assert params == ["a1", "b1", "a2", "b2", "c2"]

def test_build_callables():
    expr = "(exp(i) + a1*x + b1) / (1 + c2*x)"
    fspec = build_callables(expr)
    assert "a1" in fspec.param_names and "c2" in fspec.param_names
    # 簡單評估
    import numpy as np
    i = np.array([1.0, 1.0])
    x = np.array([0.0, 1.0])
    theta = [0.5, 0.1, 0.05]
    y = fspec.eval_f(i, x, theta)
    dy = fspec.eval_dfdx(i, x, theta)
    assert y.shape == x.shape
    assert dy.shape == x.shape
