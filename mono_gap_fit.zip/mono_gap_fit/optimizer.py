
# -*- coding: utf-8 -*-
"""
optimizer.py
------------
兩階段最佳化：Phase-1（軟限制）→ Phase-2（trust-constr 帶顯式不等式）。
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy.optimize import minimize, NonlinearConstraint

@dataclass
class ParamIndexer:
    g_list: List[str]
    P: int  # 參數數量/每 g

    def slice_of(self, g: str) -> slice:
        idx = self.g_list.index(g)
        return slice(idx*self.P, (idx+1)*self.P)

    def unpack(self, theta: np.ndarray) -> Dict[str, np.ndarray]:
        out: Dict[str, np.ndarray] = {}
        for idx, g in enumerate(self.g_list):
            out[g] = theta[idx*self.P:(idx+1)*self.P]
        return out

def make_objectives(df_obs,
                    fspec,
                    indexer: ParamIndexer,
                    weights: Optional[np.ndarray],
                    lambda_reg: float,
                    gap_delta: float,
                    grids,
                    order_i: Dict[float, List[str]],
                    gamma: float,
                    epsilon: float,
                    zeta: float):
    """
    建構 Phase-1 的 scalar 目標（含軟懲罰）與 Phase-2 的目標（不含軟懲罰）。
    """
    # 觀測索引拆組（以 g 分組利於向量化）
    obs_by_g = {}
    for g, sub in df_obs.groupby("g"):
        arr = sub[["i", "x", "y"]].values.astype(float)
        w = np.ones(len(sub), dtype=float) if weights is None else weights[sub.index.values]
        obs_by_g[str(g)] = (arr[:, 0], arr[:, 1], arr[:, 2], w)

    def sse(theta: np.ndarray) -> float:
        theta_by_g = indexer.unpack(theta)
        total = 0.0
        for g, (i_arr, x_arr, y_arr, w_arr) in obs_by_g.items():
            pred = fspec.eval_f(i_arr, x_arr, theta_by_g[g])
            total += float(np.sum(w_arr * (y_arr - pred)**2))
        return total

    def sim_reg(theta: np.ndarray) -> float:
        total = 0.0
        for k in range(len(indexer.g_list)-1):
            sl1 = slice(k*indexer.P, (k+1)*indexer.P)
            sl2 = slice((k+1)*indexer.P, (k+2)*indexer.P)
            diff = theta[sl2] - theta[sl1]
            total += float(np.dot(diff, diff))
        return lambda_reg * total

    # 軟化 gap 懲罰
    def gap_soft(theta: np.ndarray) -> float:
        theta_by_g = indexer.unpack(theta)
        total = 0.0
        for i_val, order in order_i.items():
            xgrid = grids["cross"][i_val]
            for k in range(len(order)-1):
                g1, g2 = order[k], order[k+1]
                i_arr = np.full_like(xgrid, i_val, dtype=float)
                f1 = fspec.eval_f(i_arr, xgrid, theta_by_g[g1])
                f2 = fspec.eval_f(i_arr, xgrid, theta_by_g[g2])
                gap = f2 - f1
                total += float(np.sum(np.clip(gap_delta - gap, a_min=0.0, a_max=None)**2))
        return zeta * total

    # 分母安全懲罰
    def denom_soft(theta: np.ndarray) -> float:
        if fspec.denom_lambda is None:
            return 0.0
        theta_by_g = indexer.unpack(theta)
        total = 0.0
        for (g, i_val), xgrid in grids["mono"].items():
            i_arr = np.full_like(xgrid, i_val, dtype=float)
            dabs = fspec.denom_lambda(xgrid, i_arr, *theta_by_g[g])  # 注意 lambdify 參數順序
            total += float(np.sum(np.clip(epsilon - dabs, a_min=0.0, a_max=None)**2))
        return gamma * total

    def phase1_obj(theta: np.ndarray) -> float:
        return sse(theta) + sim_reg(theta) + gap_soft(theta) + denom_soft(theta)

    def phase2_obj(theta: np.ndarray) -> float:
        return sse(theta) + sim_reg(theta)

    return phase1_obj, phase2_obj

def make_constraints(fspec,
                     indexer: ParamIndexer,
                     s_dir: Dict[Tuple[str, float], int],
                     grids,
                     order_i: Dict[float, List[str]],
                     gap_delta: float,
                     epsilon: float) -> List[NonlinearConstraint]:
    cons: List[NonlinearConstraint] = []

    # 單調： s * dfdx >= 0
    def mono_fun(theta: np.ndarray) -> np.ndarray:
        theta_by_g = indexer.unpack(theta)
        vals = []
        for (g, i_val), xgrid in grids["mono"].items():
            i_arr = np.full_like(xgrid, i_val, dtype=float)
            dfdx = fspec.eval_dfdx(i_arr, xgrid, theta_by_g[g])
            s = s_dir[(g, i_val)]
            vals.append(s * dfdx)
        return np.concatenate(vals) if vals else np.array([], dtype=float)
    cons.append(NonlinearConstraint(mono_fun, lb=0.0, ub=np.inf))

    # 不交叉不相切： f(g_{k+1}) - f(g_k) - delta >= 0
    def gap_fun(theta: np.ndarray) -> np.ndarray:
        theta_by_g = indexer.unpack(theta)
        vals = []
        for i_val, order in order_i.items():
            xgrid = grids["cross"][i_val]
            i_arr = np.full_like(xgrid, i_val, dtype=float)
            for k in range(len(order)-1):
                g1, g2 = order[k], order[k+1]
                f1 = fspec.eval_f(i_arr, xgrid, theta_by_g[g1])
                f2 = fspec.eval_f(i_arr, xgrid, theta_by_g[g2])
                vals.append(f2 - f1 - gap_delta)
        return np.concatenate(vals) if vals else np.array([], dtype=float)
    cons.append(NonlinearConstraint(gap_fun, lb=0.0, ub=np.inf))

    # 分母安全： |d| - epsilon >= 0
    if fspec.denom_lambda is not None:
        def denom_fun(theta: np.ndarray) -> np.ndarray:
            theta_by_g = indexer.unpack(theta)
            vals = []
            for (g, i_val), xgrid in grids["mono"].items():
                i_arr = np.full_like(xgrid, i_val, dtype=float)
                dabs = fspec.denom_lambda(xgrid, i_arr, *theta_by_g[g])
                vals.append(dabs - epsilon)
            return np.concatenate(vals) if vals else np.array([], dtype=float)
        cons.append(NonlinearConstraint(denom_fun, lb=0.0, ub=np.inf))

    return cons

def optimize_phase1(theta0: np.ndarray,
                    bounds: List[Tuple[float, float]],
                    phase1_obj: Callable[[np.ndarray], float],
                    maxiter: int,
                    log: bool = True) -> np.ndarray:
    res = minimize(phase1_obj, x0=theta0, method="L-BFGS-B", bounds=bounds,
                   options={"maxiter": int(maxiter), "ftol": 1e-12})
    return res.x

def optimize_trust_constr(theta0: np.ndarray,
                          bounds: List[Tuple[float, float]],
                          phase2_obj: Callable[[np.ndarray], float],
                          constraints: List[NonlinearConstraint],
                          maxiter: int) -> Tuple[np.ndarray, dict]:
    res = minimize(phase2_obj, x0=theta0, method="trust-constr",
                   bounds=bounds, constraints=constraints,
                   options={"maxiter": int(maxiter), "verbose": 0})
    return res.x, {"success": bool(res.success), "message": res.message, "niter": int(res.niter), "status": int(res.status)}
