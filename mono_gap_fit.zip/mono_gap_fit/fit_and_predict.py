
# -*- coding: utf-8 -*-
"""
fit_and_predict.py
------------------
CLI 入口：讀取資料與函數 → 兩階段最佳化 → 產出預測、參數、格點與圖片。
"""
from __future__ import annotations
import argparse
import json
import logging
import os
import sys
import time
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from io_util import (ensure_outdir, read_data, read_function, write_data_with_predictions,
                     write_full_grid_by_i, write_params_by_g, write_run_report, write_infeasibility_report)
from func_parser import build_callables, extract_param_names
from grids import compute_x_range, build_grids
from order_dir import decide_monotonic_dirs, decide_g_order_per_i
from optimizer import (ParamIndexer, make_objectives, make_constraints,
                       optimize_phase1, optimize_trust_constr)
from plots import plot_by_i

def _parse_args(argv: Optional[Sequence[str]] = None):
    ap = argparse.ArgumentParser(description="Monotone & non-crossing curve fit with rational-function safety.")
    ap.add_argument("--data", required=True)
    ap.add_argument("--func", required=True)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--x-grid", nargs=3, type=float, metavar=("MIN_X", "MAX_X", "N"), default=None)
    ap.add_argument("--lambda", dest="lambda_", type=float, default=1.0)
    ap.add_argument("--gamma", type=float, default=10.0)
    ap.add_argument("--epsilon", type=float, default=1e-6)
    ap.add_argument("--rho-th", type=float, default=0.2)
    ap.add_argument("--gap-delta", type=float, default=1e-3)
    ap.add_argument("--g-order", type=str, default=None)
    ap.add_argument("--bounds", type=str, default=None, help="JSON 檔：可為 {param:[L,U]} 或 {g:{param:[L,U]}}")
    ap.add_argument("--weight-col", type=str, default=None, help="data.csv 權重欄位名（預設為 1）")
    ap.add_argument("--maxiter", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--loglevel", type=str, default="INFO")
    return ap.parse_args(argv)

def _init_logger(level: str):
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(message)s"
    )

def _sorted_unique_g(df: pd.DataFrame) -> List[str]:
    return sorted(df["g"].astype(str).unique().tolist())

def _load_bounds(bounds_path: Optional[str],
                 g_list: List[str],
                 param_names: List[str]) -> List[Tuple[float, float]]:
    """支援兩種 JSON：
    1) 共享： { "a1":[-1e3,1e3], ... }
    2) per g： { "g1": {"a1":[-10,10], ...}, "g2": {...} }
    """
    P = len(param_names)
    if not bounds_path:
        return [(-1e3, 1e3)] * (len(g_list) * P)
    with open(bounds_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    out: List[Tuple[float, float]] = []
    if all(isinstance(v, (list, tuple)) for v in cfg.values()):
        # 共享
        shared = {k: tuple(map(float, v)) for k, v in cfg.items()}
        for g in g_list:
            for p in param_names:
                out.append(shared.get(p, (-1e3, 1e3)))
    else:
        # per g
        for g in g_list:
            gd = cfg.get(g, {})
            for p in param_names:
                out.append(tuple(map(float, gd.get(p, (-1e3, 1e3)))))
    return out

def _init_theta(g_list: List[str], param_names: List[str], seed: int, fspec) -> np.ndarray:
    rng = np.random.default_rng(seed)
    P = len(param_names)
    theta = np.zeros(len(g_list)*P, dtype=float)
    # 預設小值；分母參數偏大一點
    denom_params = set([str(s) for s in (fspec.expr.as_numer_denom()[1]).free_symbols]) if fspec.expr.as_numer_denom()[1] != 1 else set()
    for gi, g in enumerate(g_list):
        for pj, p in enumerate(param_names):
            val = 1e-2 * (1.0 + 0.1*rng.standard_normal())
            if p in denom_params:
                val = 1e-1 * (1.0 + 0.1*rng.standard_normal())
            theta[gi*P + pj] = val
    return theta

def _weights_from_df(df: pd.DataFrame, weight_col: Optional[str]) -> Optional[np.ndarray]:
    if weight_col is None or weight_col not in df.columns:
        return None
    w = pd.to_numeric(df[weight_col], errors="coerce").values.astype(float)
    w = np.where(np.isfinite(w), w, 1.0)
    return w

def run_pipeline(args=None) -> None:
    args = _parse_args(args)
    _init_logger(args.loglevel)
    t0 = time.time()
    ensure_outdir(args.outdir)

    df = read_data(args.data)
    func_str = read_function(args.func)
    fspec = build_callables(func_str)
    param_names = fspec.param_names

    g_list = _sorted_unique_g(df)
    bounds = _load_bounds(args.bounds, g_list, param_names)

    # x 範圍與格點
    min_x, max_x, N_plot = compute_x_range(df, args.x_grid)
    grids = build_grids(df, min_x, max_x, N_mono=101, N_cross=201, N_plot=int(N_plot))

    # 初值
    theta0 = _init_theta(g_list, param_names, args.seed, fspec)
    indexer = ParamIndexer(g_list=g_list, P=len(param_names))
    theta0_by_g = indexer.unpack(theta0)

    # 單調方向與 g 排序
    s_dir = decide_monotonic_dirs(df, args.rho_th, fspec, theta0_by_g, grids["mono"])
    order_i = decide_g_order_per_i(df, fspec, theta0_by_g, args.g_order)

    # Phase-1：軟限制
    df_obs = df.dropna(subset=["y"]).copy()
    weights = _weights_from_df(df, args.weight_col)
    phase1_obj, phase2_obj = make_objectives(df_obs, fspec, indexer, weights,
                                             lambda_reg=args.lambda_,
                                             gap_delta=args.gap_delta,
                                             grids=grids, order_i=order_i,
                                             gamma=args.gamma, epsilon=args.epsilon, zeta=1e3)
    theta1 = optimize_phase1(theta0, bounds, phase1_obj, maxiter=args.maxiter)

    # Phase-2：顯式不等式
    constraints = make_constraints(fspec, indexer, s_dir, grids, order_i, args.gap_delta, args.epsilon)
    theta_hat, opt_info = optimize_trust_constr(theta1, bounds, phase2_obj, constraints, maxiter=args.maxiter)

    # 預測與輸出
    theta_by_g = indexer.unpack(theta_hat)

    # 生成預測 y_hat
    yhat = np.empty(len(df), dtype=float)
    for g, sub in df.groupby("g"):
        idx = sub.index.values
        i_arr = sub["i"].values.astype(float)
        x_arr = sub["x"].values.astype(float)
        yhat[idx] = fspec.eval_f(i_arr, x_arr, theta_by_g[str(g)])
    df["y_hat"] = yhat
    df["residual"] = np.where(df["y"].notna(), df["y"] - df["y_hat"], np.nan)
    # 單調方向欄位與 sparsity_flag
    dirs = []
    sparse = []
    for row in df.itertuples(index=False):
        g = str(getattr(row, "g"))
        i = float(getattr(row, "i"))
        dirs.append("increasing" if s_dir.get((g, i), +1) > 0 else "decreasing")
        sub = df[(df["g"].astype(str)==g) & (df["i"]==i)]
        sparse.append(bool(np.sum(sub["y"].notna().values) < 2))
    df["monotonic_dir"] = dirs
    df["sparsity_flag"] = sparse

    # full_grid_by_i
    rows = []
    for i_val, order in order_i.items():
        xgrid = grids["plot"][i_val]
        for g in order:
            i_arr = np.full_like(xgrid, i_val, dtype=float)
            fhat = fspec.eval_f(i_arr, xgrid, theta_by_g[g])
            rows.append(pd.DataFrame({"i": i_val, "g": g, "x": xgrid, "f_hat": fhat}))
    df_grid = pd.concat(rows, ignore_index=True) if rows else pd.DataFrame(columns=["i","g","x","f_hat"])

    # 輸出檔
    write_data_with_predictions(args.outdir, df)
    write_params_by_g(args.outdir, g_list, param_names, theta_hat)
    write_full_grid_by_i(args.outdir, df_grid)

    # 繪圖
    plot_by_i(args.outdir, df, fspec, theta_by_g, grids["plot"], s_dir)

    # 報告與違反度摘要
    infeas_rows = []
    # 重新檢查最小 gap
    for i_val, order in order_i.items():
        xgrid = grids["cross"][i_val]
        i_arr = np.full_like(xgrid, i_val, dtype=float)
        for k in range(len(order)-1):
            g1, g2 = order[k], order[k+1]
            f1 = fspec.eval_f(i_arr, xgrid, theta_by_g[g1])
            f2 = fspec.eval_f(i_arr, xgrid, theta_by_g[g2])
            gap = f2 - f1
            min_gap = float(np.min(gap))
            if min_gap < args.gap_delta:
                where = int(np.argmin(gap))
                infeas_rows.append({"type": "gap", "i": i_val, "g_left": g1, "g_right": g2,
                                    "x": float(xgrid[where]), "violation": float(args.gap_delta - min_gap)})
    # 分母安全
    if fspec.denom_lambda is not None:
        for (g, i_val), xgrid in grids["mono"].items():
            i_arr = np.full_like(xgrid, i_val, dtype=float)
            dabs = fspec.denom_lambda(xgrid, i_arr, *theta_by_g[g])
            min_d = float(np.min(dabs))
            if min_d < args.epsilon:
                where = int(np.argmin(dabs))
                infeas_rows.append({"type": "denom", "i": i_val, "g": g,
                                    "x": float(xgrid[where]), "violation": float(args.epsilon - min_d)})
    write_infeasibility_report(args.outdir, sorted(infeas_rows, key=lambda r: -r["violation"])[:200])

    # 報告
    import platform
    report = {
        "cli_args": vars(args),
        "param_names": param_names,
        "g_list": g_list,
        "opt_info": opt_info,
        "versions": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
        },
        "timing_sec": {
            "total": float(time.time()-t0)
        },
        "violations": {
            "count": int(len(infeas_rows)),
            "max_violation": float(max([r["violation"] for r in infeas_rows], default=0.0))
        }
    }
    write_run_report(args.outdir, report)
    print(f"[OK] 完成。輸出位於：{args.outdir}")

if __name__ == "__main__":
    run_pipeline()
