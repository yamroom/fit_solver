
# -*- coding: utf-8 -*-
"""
order_dir.py
------------
決定單調方向 s_{g,i} 與固定每個 i 下的 g 排序。
"""
from __future__ import annotations
from typing import Dict, List, Tuple, Optional
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

def decide_monotonic_dirs(df: pd.DataFrame,
                          rho_th: float,
                          fspec,
                          theta0_by_g: Dict[str, np.ndarray],
                          grids_mono: Dict[Tuple[str, float], np.ndarray]) -> Dict[Tuple[str, float], int]:
    """
    返回字典 { (g,i): +1 or -1 }。不足 2 點則以該 i 的眾數方向，仍不足則 +1。
    否則先用 Spearman 判斷；若 |rho| < rho_th，則以初始參數下的導數違反度決定方向：
        s=+1 時 sum(max(0, -dfdx)) 與 s=-1 時 sum(max(0, +dfdx))，取較小者。
    """
    s_dir: Dict[Tuple[str, float], int] = {}
    # 先對具 ≥2 點的 (g,i) 基於 Spearman 決定
    spearman_dir: Dict[Tuple[str, float], int] = {}
    for (g, i), sub in df.groupby(["g", "i"]):
        g, i = str(g), float(i)
        obs = sub.dropna(subset=["y"])
        if len(obs) >= 2:
            rho = spearmanr(obs["x"].values, obs["y"].values, nan_policy="omit").correlation
            if rho is None or np.isnan(rho):
                continue
            if rho >= rho_th:
                spearman_dir[(g, i)] = +1
            elif rho <= -rho_th:
                spearman_dir[(g, i)] = -1
    # 對於未確定的，以導數違反度度量
    for (g, i), sub in df.groupby(["g", "i"]):
        g, i = str(g), float(i)
        if (g, i) in spearman_dir:
            s_dir[(g, i)] = spearman_dir[(g, i)]
            continue
        xgrid = grids_mono.get((g, i))
        if xgrid is None:
            continue
        theta = theta0_by_g[g]
        dfdx = fspec.eval_dfdx(np.full_like(xgrid, i, dtype=float), xgrid, theta)
        # s=+1: 罰負導數； s=-1: 罰正導數
        v_pos = np.sum(np.clip(-dfdx, a_min=0.0, a_max=None))
        v_neg = np.sum(np.clip(+dfdx, a_min=0.0, a_max=None))
        s_dir[(g, i)] = +1 if v_pos <= v_neg else -1
    # 不足 2 點的回退：以該 i 的眾數方向
    by_i = {}
    for (g, i), s in s_dir.items():
        by_i.setdefault(i, []).append(s)
    for (g, i), sub in df.groupby(["g", "i"]):
        g, i = str(g), float(i)
        obs = sub.dropna(subset=["y"])
        if len(obs) < 2 and (g, i) not in s_dir:
            if i in by_i and len(by_i[i]) > 0:
                vals = np.array(by_i[i], dtype=int)
                s_dir[(g, i)] = int(np.sign(np.sum(vals))) if np.sum(vals) != 0 else +1
            else:
                s_dir[(g, i)] = +1
    return s_dir

def decide_g_order_per_i(df: pd.DataFrame,
                         fspec,
                         theta0_by_g: Dict[str, np.ndarray],
                         g_order_csv: Optional[str]) -> Dict[float, List[str]]:
    """
    若有 g_order_csv（欄位 i,g,rank），則直接採用。
    否則以每個 i 下各 g 的觀測中位 y（不足則以初始預測中位）排序（小→大）。
    """
    if g_order_csv:
        user = pd.read_csv(g_order_csv)
        if not set(["i", "g", "rank"]).issubset(user.columns):
            raise ValueError("order.csv 需要欄位：i,g,rank")
        order = {}
        for i, sub in user.groupby("i"):
            sub = sub.sort_values("rank")
            order[float(i)] = [str(g) for g in sub["g"].tolist()]
        return order
    # 自動排序
    order: Dict[float, List[str]] = {}
    for i, sub in df.groupby("i"):
        i_val = float(i)
        g_values = sorted(sub["g"].astype(str).unique().tolist())
        ranks = []
        for g in g_values:
            sub_gi = sub[sub["g"].astype(str) == g]
            obs = sub_gi.dropna(subset=["y"])
            if len(obs) > 0:
                med = float(np.nanmedian(obs["y"].values))
            else:
                # 用初始參數在觀測 x 的預測中位
                theta = theta0_by_g[g]
                preds = fspec.eval_f(np.full(len(sub_gi), i_val, dtype=float),
                                     sub_gi["x"].values.astype(float), theta)
                med = float(np.nanmedian(preds))
            ranks.append((g, med))
        ranks.sort(key=lambda t: t[1])  # 小->大
        order[i_val] = [g for g, _ in ranks]
    return order
