
# -*- coding: utf-8 -*-
"""
io_util.py
----------
讀寫 data.csv、function.txt，與所有輸出檔。
"""
from __future__ import annotations
import json
import logging
import os
from typing import Any, Dict, Iterable, List, Optional

import numpy as np
import pandas as pd

try:
    import yaml  # type: ignore
    _HAS_YAML = True
except Exception:
    _HAS_YAML = False


REQUIRED_DATA_COLS = ["g", "i", "x", "y"]

def read_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    for c in REQUIRED_DATA_COLS:
        if c not in df.columns:
            raise ValueError(f"data.csv 缺少欄位：{c}")
    # 型別與缺失處理
    df["g"] = df["g"].astype(str)
    df["i"] = pd.to_numeric(df["i"], errors="coerce")
    df["x"] = pd.to_numeric(df["x"], errors="coerce")
    df["y"] = pd.to_numeric(df["y"], errors="coerce")
    return df

def read_function(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        line = f.read().strip()
    if not line:
        raise ValueError("function.txt 為空")
    return line

def ensure_outdir(path: str) -> None:
    os.makedirs(path, exist_ok=True)
    os.makedirs(os.path.join(path, "plots_by_i"), exist_ok=True)

def write_params_by_g(outdir: str, g_list: List[str], param_names: List[str], theta: np.ndarray) -> None:
    """theta 為全域向量（依 g 連接）"""
    P = len(param_names)
    rows = []
    for gi, g in enumerate(g_list):
        sl = slice(gi*P, (gi+1)*P)
        rows.append({"g": g, **{param_names[j]: float(theta[sl][j]) for j in range(P)}})
    wide = pd.DataFrame(rows)
    long = wide.melt(id_vars=["g"], var_name="param", value_name="value")
    wide.to_csv(os.path.join(outdir, "params_by_g.csv"), index=False)
    long.to_csv(os.path.join(outdir, "params_by_g_long.csv"), index=False)

def write_data_with_predictions(outdir: str, df_pred: pd.DataFrame) -> None:
    df_pred.to_csv(os.path.join(outdir, "data_with_predictions.csv"), index=False)

def write_full_grid_by_i(outdir: str, df_grid: pd.DataFrame) -> None:
    df_grid.to_csv(os.path.join(outdir, "full_grid_by_i.csv"), index=False)

def write_run_report(outdir: str, report: Dict[str, Any]) -> None:
    path = os.path.join(outdir, "run_report.yaml")
    if _HAS_YAML:
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(report, f, allow_unicode=True, sort_keys=False)
    else:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)

def write_infeasibility_report(outdir: str, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    import pandas as pd
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(outdir, "infeasibility_report.csv"), index=False)
