
# -*- coding: utf-8 -*-
"""
func_parser.py
--------------
安全解析 function.txt，抽取參數順序（依原始字串出現順序），
以 sympy 建立 f(x,i; θ)、df/dx，以及若為有理函數則辨識分母 d(x,i; θ)。
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import sympy as sp

# 允許的函數白名單（大小寫都接受）
_ALLOWED_FUNCS = {
    "exp": sp.exp, "log": sp.log, "sqrt": sp.sqrt,
    "sin": sp.sin, "cos": sp.cos, "tan": sp.tan, "tanh": sp.tanh,
    "abs": sp.Abs
}
# 加入大小寫變體
_ALLOWED_FUNCS.update({k.upper(): v for k, v in _ALLOWED_FUNCS.items()})
_ALLOWED_VARS = {"x", "i"}  # 保留識別字

IDENT_RE = re.compile(r"[A-Za-z_]\w*")

@dataclass
class FunctionSpec:
    """封裝可呼叫物件與中介資訊。"""
    expr: sp.Expr
    param_names: List[str]
    f_lambda: Callable
    dfdx_lambda: Callable
    denom_lambda: Optional[Callable]

    def eval_f(self, i: np.ndarray, x: np.ndarray, theta: Sequence[float]) -> np.ndarray:
        """向量化評估 f(i,x;θ)。"""
        args = [x, i] + list(theta)
        return np.asarray(self.f_lambda(*args), dtype=float)

    def eval_dfdx(self, i: np.ndarray, x: np.ndarray, theta: Sequence[float]) -> np.ndarray:
        args = [x, i] + list(theta)
        return np.asarray(self.dfdx_lambda(*args), dtype=float)

    def eval_denom(self, i: np.ndarray, x: np.ndarray, theta: Sequence[float]) -> Optional[np.ndarray]:
        if self.denom_lambda is None:
            return None
        args = [x, i] + list(theta)
        return np.asarray(self.denom_lambda(*args), dtype=float)

def _safe_sympify(expr_str: str) -> sp.Expr:
    """以白名單解析表達式。把 ^ 轉為 **。"""
    expr_str = expr_str.replace("^", "**")
    local_dict = dict(_ALLOWED_FUNCS)
    # 顯式建立符號 x, i （避免被誤判為參數）
    local_dict.update({"x": sp.Symbol("x"), "i": sp.Symbol("i")})
    try:
        expr = sp.sympify(expr_str, locals=local_dict)
    except Exception as e:
        # 再試一次：清理多餘空白
        try:
            expr = sp.sympify(" ".join(expr_str.split()), locals=local_dict)
        except Exception as e2:
            raise ValueError(f"函數解析失敗：{e}") from e2
    # 安全檢查：不得出現非白名單函數或未宣告名稱
    free_symbols = {str(s) for s in expr.free_symbols}
    # 允許的識別字：x, i, 以及參數名稱（稍後檢查）。
    # 這裡僅提前阻擋已知黑名單：
    return expr

def extract_param_names(expr_str: str) -> List[str]:
    """
    從原始字串依出現順序抽取參數名稱（排除 x、i 與白名單函數名）。
    以避免 sympy.free_symbols 無序的問題。
    """
    expr_str = expr_str.replace("^", "**")
    seen = set()
    params: List[str] = []
    for tok in IDENT_RE.findall(expr_str):
        if tok in _ALLOWED_VARS:
            continue
        if tok in _ALLOWED_FUNCS:
            continue
        # 常數如 'pi','E' 不在白名單內，禁止；若用到請擴充白名單。
        if tok not in seen:
            seen.add(tok)
            params.append(tok)
    # 最終安全：應與 sympy 解析的自由符號一致（扣除 x,i）
    expr = _safe_sympify(expr_str)
    free = {str(s) for s in expr.free_symbols} - _ALLOWED_VARS
    if set(params) != free:
        # 保留原順序，但需完全覆蓋自由符號；否則報錯協助使用者修正。
        missing = free - set(params)
        extra = set(params) - free
        if missing or extra:
            raise ValueError(
                f"參數抽取與 sympy 自由符號不一致；缺少 {sorted(missing)}，多出 {sorted(extra)}。"
            )
    return params

def build_callables(expr_str: str) -> FunctionSpec:
    """
    解析字串並產生 f, df/dx, denom 三個 callable。
    f(x, i, *theta) 的參數順序與 `extract_param_names` 回傳一致。
    """
    expr = _safe_sympify(expr_str)
    params = extract_param_names(expr_str)
    # 準備 lambdify 參數順序
    x, i = sp.symbols("x i")
    sym_params = [sp.Symbol(n) for n in params]

    # 一階導數
    dfdx = sp.diff(expr, x)

    # 分母辨識
    num, den = sp.fraction(sp.together(expr))
    denom_expr = den if den != 1 else None

    # lambdify：使用 numpy 後端
    arg_syms = [x, i] + sym_params
    f_lambda = sp.lambdify(arg_syms, expr, modules="numpy")
    dfdx_lambda = sp.lambdify(arg_syms, dfdx, modules="numpy")
    denom_lambda = None
    if denom_expr is not None:
        denom_lambda = sp.lambdify(arg_syms, sp.Abs(denom_expr), modules="numpy")  # 直接回傳 |d| 方便約束

    return FunctionSpec(expr=expr, param_names=params, f_lambda=f_lambda, dfdx_lambda=dfdx_lambda, denom_lambda=denom_lambda)
